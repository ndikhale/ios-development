//
//  ViewController.swift
//  Exercise3_Dhikale_Nilesh
//
//  Created by student on 9/9/22.
//

import UIKit

class ViewController: UIViewController, AddBullet, UpdateTopicName {
    
    @IBOutlet weak var memorizer: UILabel!
    
    @IBOutlet weak var iconImg: UIImageView!
    
    @IBOutlet weak var topicsLabel: UILabel!
    
    @IBOutlet weak var topicsTextView: UITextView!
    
    var topicName = "";
    var topicIndex = 0;
    
    var topics = ["View Controller", "UIKit", "UIAlertController"];
    
    var topicDescription = ["⭐︎ Manage interface and facilitate navigation around app's content\n⭐︎ Defines the behavior for common VCs\n⭐︎ Updates the content of the view", "⭐︎ Provides required iOS infrastructure\n⭐︎ Window and view architecture\n⭐︎ Animation, Document, and Printing support\n⭐︎ Based on MVC design pattern", "⭐︎ Object that displays an alert message\n⭐︎ Configure alerts and action sheets\n⭐︎ Intended to be used as-is\n⭐︎ Does not support subclassing"];
    
    let iconImages = [UIImage(named: "1.png"),
                      UIImage(named: "2.png"),
                      UIImage(named: "3.png")];
    
    var topicIdx = 0;
    
    override func viewDidLoad() {
        super.viewDidLoad();

        topicIdx = topicIndex
        showTopic();
    }
    
    func viewLoadSetup(){
        topicIdx = topicIndex
        showTopic()
    }
    
    func addBulletValue(textValue: String) {
        topicDescription[topicIndex] = topicDescription[topicIndex] + "\n⭐︎ " + textValue;
        viewLoadSetup()
    }
    
    func updateTopicName(newTopicName: String) {
        topics[topicIndex] = newTopicName;
        viewLoadSetup()
    }
    
    func showTopic() {
        iconImg.image = iconImages[topicIdx] as! UIImage;
        topicsLabel.text = topics[topicIdx];
        topicsTextView.text = topicDescription[topicIdx];
    }
    
    @IBAction func nextTopic(_ sender: Any) {
        topicIdx = (topicIdx+1)%3;
        showTopic();
    }
    
    @IBAction func topicSelector(_ sender: Any) {
        let actionSheetAlert = UIAlertController(title: "Pick a topic", message: "", preferredStyle: .actionSheet);
        
        for topic in topics {
            actionSheetAlert.addAction(UIAlertAction(title: topic, style: .default, handler: {_ in
                self.topicIdx = self.topics.firstIndex(of: topic)!;
                self.showTopic();
            }))
        }
        actionSheetAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: {_ in
            self.dismiss(animated: true, completion: nil);
            
        }));
        self.present(actionSheetAlert, animated: true, completion: nil);
    }
    
    @IBAction func addBulletAction(_ sender: Any) {
        topicIndex = topicIdx;
        self.topicName = topics[topicIndex];
        performSegue(withIdentifier: "homeToAddBullet", sender: self);
    }
    
    @IBAction func editTopicAction(_ sender: Any) {
        topicIndex = topicIdx;
        self.topicName = topics[topicIndex];
        performSegue(withIdentifier: "homeToEditTopic", sender: self);
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "homeToAddBullet" {
            let segueAddBullet = segue.destination as! AddBulletViewController
            segueAddBullet.finalTopicName = self.topicName;
            segueAddBullet.delegate = self;
        }
        
        if segue.identifier == "homeToEditTopic" {
            let segueEdit = segue.destination as! EditTopicNameViewController
            segueEdit.topicName = self.topicName;
            segueEdit.delegate = self;
        }
    }
}
