//
//  EditTopicNameViewController.swift
//  Exercise3_Dhikale_Nilesh
//
//  Created by student on 9/10/22.
//

import UIKit

protocol UpdateTopicName {
    func updateTopicName(newTopicName: String);
}

class EditTopicNameViewController: UIViewController {
    var delegate: UpdateTopicName?
    var topicName = "";
    var newTopicName = "";

    @IBOutlet weak var updateTopicText: UITextView!
    @IBOutlet weak var topicLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        topicLabel.text = topicName;
    }

    @IBAction func saveAction(_ sender: Any) {
        newTopicName = updateTopicText.text;
        delegate?.updateTopicName(newTopicName: newTopicName);
        dismiss(animated: true, completion: nil);
    }
    
    @IBAction func cancelAction(_ sender: Any) {
        dismiss(animated: true, completion: nil);
    }
}
