//
//  AddBulletViewController.swift
//  Exercise3_Dhikale_Nilesh
//
//  Created by student on 9/10/22.
//

import UIKit

protocol AddBullet {
    func addBulletValue(textValue: String);
}

class AddBulletViewController: UIViewController {
    var finalTopicName = "";
    var topicIn = 0;
    var finalAddBulletValue = "";
    
    var delegate: AddBullet?
    
    @IBOutlet weak var topicLabel: UILabel!
    
    @IBOutlet weak var topicTextView: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        topicLabel.text = finalTopicName;
    }

    @IBAction func saveAction(_ sender: Any) {
        finalAddBulletValue = topicTextView.text;
        delegate?.addBulletValue(textValue: finalAddBulletValue)
        dismiss(animated: true, completion: nil);
    }
    
    @IBAction func cancelAction(_ sender: Any) {
        dismiss(animated: true, completion: nil);
    }
}
